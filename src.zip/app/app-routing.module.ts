import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AuthGuard } from './service/auth.guard';
import { ErrorPageComponent } from './error-page/error-page.component';
import { DatatableComponent } from './datatable/datatable.component';


const routes: Routes = [{
  path: "login",
  component: LoginComponent
},
{
  path: "dashboard",
  component: DashboardComponent
},
{
  path: "dashboard/admin",
  component: DashboardComponent,
  canActivate: [AuthGuard]
},
{
  path: "error",
  component: ErrorPageComponent
},
{
  path: "datatable",
  component: DatatableComponent
},
{
  path: "**",
  redirectTo: 'dashboard',
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes,{ useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
