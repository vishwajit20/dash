import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import {environment} from 'src/environments/environment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string;
  password: string;
  location: string;
  locations: any = ['CDG', 'CGN', 'MXP', 'CPH', 'DXB', 'KIX', 'PVG', 'SYD'];

  @ViewChild('errormessage') errormessage: ElementRef;


  constructor(private http: HttpClient, private router: Router, private loginservice: LoginService) { }

  selectChangeHandler(event: any) {
    //update the ui
    this.location = event.target.value;
  }

  submit(userName, password, location) {
    console.log(userName, password, location);
      this.http.post(environment.baseAPIUrl+"/login", { username:userName, password:password}, { responseType: 'text' })
       .subscribe(response => {
    //if (userName === "Admin" && password === "Admin") {
       if (response === "validated") { 
        sessionStorage.setItem('auth', 'true');
        this.router.navigate(['dashboard/admin']);
        this.loginservice.loginStatus.next(false);
      } else {
        sessionStorage.setItem('auth', 'false');
        console.error('invalid username or password');
        this.loginservice.loginStatus.next(true);
        this.errormessage.nativeElement.innerHTML = 'Please enter valid Username and Password';
      }
    });
}

}

