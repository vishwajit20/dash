import { Component, AfterViewInit, ViewChild, ViewChildren, QueryList, ElementRef, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { DEP_SERVERS, MESSAGE, LOCATIONS } from 'src/assets/constants';
import { ValueConverter } from '@angular/compiler/src/render3/view/template';
import { Title } from '@angular/platform-browser';
import { __spreadArrays } from 'tslib';
import {environment} from 'src/environments/environment';

@Component({
  selector: 'app-server-details',
  templateUrl: './server-details.component.html',
  styleUrls: ['./server-details.component.scss']
})
export class ServerDetailsComponent implements AfterViewInit {

  @ViewChild('overlay') overlay: any;
  @ViewChildren('checkbox') checkbox: QueryList<ElementRef>;
  city: any = [];
 
  selectedServerName;
  serverStatusGroup;
  serverStatusGroupArray;
  servers;
  selectedLocation = 0;
  message = MESSAGE;
  showCheckBox;
  serverGroupAll = [];
  @Input('location') location;
  dependentServers = DEP_SERVERS;
  dependentServersGroup = {};
  serverGroup = [];
  locName:any;

  constructor(private http: HttpClient) {
    this.gethubList();
    this.getServerDetails(0);
    this.showCheckBox = sessionStorage.getItem('auth') && window.location.href.split('/').pop() === "admin";
    console.log(sessionStorage.getItem('auth'), window.location.href.split('/').pop());
  }

  ngAfterViewInit() {
    this.hideOverlay();
  }
  gethubList()
  {
    console.log(environment.baseAPIUrl);
    
    this.http.get(environment.baseAPIUrl+'HubLocationList/').subscribe((details) => {
      console.log(details);
      this.city = details;
    });
  }
  
  /**
   * gets the data form the server
   */
  getServerDetails(locName) {
    this.selectedLocation = locName;
    console.log(this.city[locName]);
    
    this.http.get(environment.baseAPIUrl+'HSAppServerAndLocationDetails/'+this.city[locName]).subscribe((details) => {
      console.log(details);
      this.formateServerDetails(details, this.city[locName]);
    });
  }

  /**
   * formate the details of the server
   * @param details details of the servers
   */
  formateServerDetails(details, locValue) {

    this.serverGroup = [];
    const appName = details.filter((value: any) => locValue === value.hubLocation).map(value => ({

      name: value.appName,
      status: value.serverStatus,
      details: {
        serverName: value.serverName,
        serverInfo: value.info
      }
    })
    );
console.log(appName);

    this.serverGroup.push(...appName);
    return this.serverGroup;
  }

  // filterServers(location) {
  //   //console.log(this.details);
    
  //   this.selectedLocation = location;
  //   if (localStorage.getItem('DETAILS' + '_' + this.city[location]) === null) {
  //     localStorage.setItem('DETAILS' + '_' + this.city[location],
  //       JSON.stringify(this.formateServerDetails(LOCATIONS['DETAILS' + '_' + this.city[location]], location)))
  //     localStorage.setItem('dependentserers', JSON.stringify(this.dependentServersGroup))
  //   } else {
  //     this.serverGroup = JSON.parse(localStorage.getItem('DETAILS' + '_' + this.city[location]));
  //     this.dependentServersGroup = JSON.parse(localStorage.getItem('dependentserers'));
  //   }
  // }

  /**
   * display  dependent serve on pop-up
   * @param status status of the server
   * @param name name of the server
   */
  display(status, name) {
    console.log(status, name);
    this.http.get(environment.baseAPIUrl+'DepAppDetails/'+name).subscribe((details) => {
    console.log(details);
    this.dependentServersGroup[name] = details;  

    if (status === 'stopped') {
      this.overlay.nativeElement.style.display = 'flex';
      this.selectedServerName = name;
      this.servers = { name, children: details };
      console.log(this.servers);
    }
  });
  }

  hideOverlay() {
    this.overlay.nativeElement.style.display = 'none';
  }

  submit(status) {

    let matCheckbox = this.checkbox.filter((value: any) => value.nativeElement.checked == true);
    if (matCheckbox.length === 0) {
      alert('Please select any server before performing outage Start/Stop');
    }
    let checkedServers = matCheckbox.map((element: any) => {
      let [serverName, serverStatus] = element.nativeElement.value.split(',');
      if (status === 'start' && serverStatus === 'running') {
        alert(`No outage found for ${serverName} `);
        return '';
      }
      else if (status === 'stop' && serverStatus === 'stopped') {
        alert(`${serverName} outage is on going`);
        return '';
      }
      else if (status === 'start') {
        return serverStatus !== 'running' ? serverName : '';
      } else if (status === 'stop') {
        return serverStatus !== 'stopped' ? serverName : ''
      } else {
        return '';
      }
    }).filter((value: any) => value !== '');

    if (checkedServers.length < 1) {
      // alert(`state`)
      this.checkbox.forEach((value: any) => value.nativeElement.checked = false);
      return 0;
    }

    if (confirm(`Do you Want to ${status == 'start' ? 'stop' : 'start'} the selected servers?`)) {
      console.log(this.serverGroup, checkedServers, status);
      console.log(this.city[this.selectedLocation]);      
      let hubsortLoc = this.city[this.selectedLocation];
      
      this.serverGroup = this.changeState(this.serverGroup, checkedServers, status);
      console.log(this.serverGroup);
      this.checkbox.forEach((value: any) => value.nativeElement.checked = false);
      localStorage.setItem('DETAILS' + '_' + this.city[this.selectedLocation],
        JSON.stringify(this.serverGroup))
      alert(`${checkedServers} server outage ${status == 'start' ? 'stopp' : 'start'}ed`)
      
      if(hubsortLoc === 'ALL')
      {
          this.http.post(environment.baseAPIUrl+"UpdateAllStatus/", { appNames : checkedServers, serverStatus :status }, { responseType: 'text' })
        .subscribe(response => {
          if (response === "ok") {
            console.log(response);
          }
        });
      }
      else{
      this.http.post(environment.baseAPIUrl+"UpdateLocStatus/", { hubLocation: hubsortLoc, appNames : checkedServers, serverStatus :status }, { responseType: 'text' })
        .subscribe(response => {
          if (response === "ok") {
            console.log(response);
          }
        });
      }
    } else {
      this.checkbox.forEach((value: any) => value.nativeElement.checked = false);
    }
  }

  changeState(servers, checkedServers, status) {
    let serversStatus = servers.map(value => {
      if (status === 'start' && value.status === 'stopped' && checkedServers.includes(value.name)) {
        value.status = 'running';
        return value;
      } else if (status === 'stop' && value.status === 'running' && checkedServers.includes(value.name)) {
        value.status = 'stopped'
        return value;
      } else {
        return value;
      }
    });
    return serversStatus;
  }
}
