import {Component, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';
import { HttpClient } from '@angular/common/http';
import {environment} from 'src/environments/environment';

@Component({
  selector: 'app-datatable',
  styleUrls: ['datatable.component.scss'],
  templateUrl: 'datatable.component.html'
})
export class DatatableComponent {
  loginStatus;
  ticketDetails;
  constructor(private route: Router, private loginService: LoginService, private http: HttpClient) {
    this.loginStatus = !sessionStorage.getItem('auth');
    this.loginService.loginStatus$.subscribe((value: boolean) => {
    this.loginStatus = value;
    })
    this.getTicketDetails();
  }

  getTicketDetails()
  {
    this.http.get(environment.baseAPIUrl+'HubstackCCTickets/').subscribe((details) => {
      //console.log(details);
      this.ticketDetails = details;
      this.ticketDetails.filter((value: any) => {
      });
    });
  }
  
 
  logout() {
    sessionStorage.removeItem('auth');
    this.loginStatus = false;
    this.route.navigate(['dashboard']);
    this.loginService.loginStatus.next(true);
  }
  
   
}
