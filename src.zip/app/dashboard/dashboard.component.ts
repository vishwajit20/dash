import { Component, OnInit, ViewChildren, QueryList, ElementRef, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements AfterViewInit {
  serverGroup = []
  select = false;
  

  constructor(private http: HttpClient , private router: Router) {
    
    if(sessionStorage.getItem('auth')){
      router.navigateByUrl('dashboard/admin')
    }

    // http.get('http://localhost:8080/HSApp').subscribe((value: []) => {
    //   console.log(value);
    //   value.forEach((element: any) => {
    //     this.serverGroup.push({ name: element.appName, status: element.serverStatus, role: element.userRole });
    //   });
    // });
  }

  ngAfterViewInit() {
    // console.log(this.checkbox);
  }

}
