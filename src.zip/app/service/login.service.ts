import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  loginStatus = new Subject();
  loginStatus$ = this.loginStatus.asObservable();

  constructor() {}
}
