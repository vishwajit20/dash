import { TestBed } from '@angular/core/testing';

import { StoreServerDataService } from './store-server-data.service';

describe('StoreServerDataService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: StoreServerDataService = TestBed.get(StoreServerDataService);
    expect(service).toBeTruthy();
  });
});
