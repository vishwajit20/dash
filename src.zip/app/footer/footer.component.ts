import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {environment} from 'src/environments/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  tooltipDiv;
  hubstackCCTicketCount : any;
  clearanceCCTicketCount : any;
  constructor( private router: Router, private http: HttpClient) { 
    this.getHubstackCCTicketDetails();
    this.getClearanceTicketDetails();
  }

  getHubstackCCTicketDetails()
  {
    this.http.get(environment.baseAPIUrl+'HubstackCCTicketsCount/').subscribe((details) => {
      console.log(details);
      this.hubstackCCTicketCount = details;
    });
  }
  getClearanceTicketDetails()
  {
    this.http.get(environment.baseAPIUrl+'ClearanceCCTicketsCount/').subscribe((details) => {
      console.log(details);
      this.clearanceCCTicketCount = details;
    });
  }

  ngOnInit() {
  }
  redirectError()
  {
    this.router.navigate(['dashboard/error']);
  }
}
