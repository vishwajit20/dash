import { Component, OnInit, AfterViewInit, Input, OnChanges } from '@angular/core';
import * as d3 from 'd3';
import { geoOrthographicRaw } from 'd3';

@Component({
  selector: 'app-tree-chart',
  templateUrl: './tree-chart.component.html',
  styleUrls: ['./tree-chart.component.scss']
})
export class TreeChartComponent implements OnChanges {

  @Input() data;

  treeData;
  margin = { top: 20, right: 90, bottom: 30, left: 90 };
  width = 500 - this.margin.left - this.margin.right;
  height = 500 - this.margin.top - this.margin.bottom;
  svg;
  i = 0; duration = 750; /* root; */
  treeMap;
  root;
  tooltipDiv;
  selectedServers = [];

  constructor() { }

  ngOnChanges() {
    this.selectedServers = []
    this.treeData = this.data;
    if (this.tooltipDiv) {
      this.tooltipDiv.style = `top:0px;left:0px;z-index:-1;opacity:0;`;
    }
    this.treeData && Object.entries(this.treeData).length ? this.createTree() : console.log('data');
  }

  createTree() {
    this.tooltipDiv = document.getElementById('tooltip');
    d3.select('svg').selectAll('g').remove();
    this.svg = d3.select('svg')
      .attr('width', this.width + this.margin.right + this.margin.left)
      .attr('height', this.height + this.margin.top + this.margin.bottom)
      .append('g')
      .attr('transform', 'translate('
        + this.margin.left + ',' + this.margin.top + ')');

    this.treeMap = d3.tree().size([this.height, this.width]);
    this.root = d3.hierarchy(this.treeData, (d) => d.children);
    this.root.x0 = this.height / 2;
    this.root.y0 = 0;

    this.root.children.forEach((d) => this.collapse(d));
    this.updateTree(this.root);
  }

  collapse(d: any) {
    if (d.children) {
      d._children = d.children;
      d._children.forEach((node: any) => this.collapse(node));
      d.children = null;
    }
  }

  updateTree(source: any) {
    const treeData = this.treeMap(this.root);
    const nodes = treeData.descendants();
    const links = treeData.descendants().slice(1);

    nodes.forEach((d) => { d.y = d.depth * 90; });

    const node = this.svg.selectAll('g.node')
      .data(nodes, (d) => d.id || (d.id = ++this.i));

    const nodeEnter = node.enter().append('g')
      .attr('class', 'node')
      .attr('transform', () => 'translate(' + source.y0 + ',' + source.x0 + ')')
      .on('click', (d) => this.click(d));


    nodeEnter.append('circle')
      .attr('class', 'node')
      .attr('r', 1e-6)
      .style('fill', (d) => { 
        return d._children ? 'lightsteelblue' : '#fff';
      })
      .style('stroke', (d) => {
        console.log(d.data);
        return d.data.status !== 'running' ? 'red' : 'green';
      });


    nodeEnter.append('text')
      .attr('dy', '.35em')
      .attr('x', (d) => {
        return d.children || d._children ? -13 : 13;
      })
      .attr('text-anchor', (d) => {
        return d.children || d._children ? 'end' : 'start';
      })
      .text((d) => d.data.name);

    nodeEnter.on('click', (d: any) => {
      let details = '';
      let detalscol = '';
      let headers = '';
      let mainHeaders = `Details of impacted Hub Areas`;
      console.log(d.data);

      if (this.selectedServers.includes(d.data.name)) {
        this.selectedServers = this.selectedServers.filter((name) => d.data.name !== name)
        this.tooltipDiv.style = `top:0px;left:0px;z-index:-1;opacity:0;`;
      } else {
        this.selectedServers[0] = d.data.name;
        this.tooltipDiv.style = `top:${d.x0 - 50}px;left:${d.y0 + 220}px;z-index:999999;opacity:1;`;
        if (!d.data.details && d.data.details === 'nodependency') {
          this.tooltipDiv.innerHTML = `<table><tr><td>No Hub operations are impacted</td></tr></table>`
        }
        else {
          if (d.data.details) {
            console.log(d.data.details);
            
            Object.keys(d.data.details).forEach(info => {
              console.log(info);
              console.log(d.data.details[info].hubActivities);
              console.log(d.data.details[info].details);
              
              headers += `<th style ='text-align: center;'>${d.data.details[info].hubActivities}</th>`
              details = '';
              d.data.details[info].details.forEach(value => {
                console.log(value.details);

                details += `<li  title = '${value.info ? value.info : 'No additonal information available'}'>
              ${value.name ? value.name : value}</li>`
              });
              detalscol += `<td><ol>${details}<ol></td>`
            });
            console.log(details);
            //this.tooltipDiv.innerHTML.style =`border-width: thick; border: solid; color: indianred; background: white;`;
            this.tooltipDiv.innerHTML = `<table><tr style ='text-align: center;'>${mainHeaders}</tr><tr>${headers}</tr><tr>${detalscol}</tr></table>`
          }else {
            this.tooltipDiv.style = `visibility: hidden`;
            this.tooltipDiv.innerHTML = `<table><tr><td>Hub operations are impacted</td></tr></table>`
          }
        }
      }
    })

    


    const nodeUpdate = nodeEnter.merge(node);

    nodeUpdate.transition()
      .duration(this.duration)
      .attr('transform', (d) => 'translate(' + d.y + ',' + d.x + ')');

    nodeUpdate.select('circle.node')
      .attr('r', '2%')
      .style('fill', (d) => d._children ? 'lightsteelblue' : '#fff')
      .attr('cursor', 'pointer');

    const nodeExit = node.exit().transition()
      .duration(this.duration)
      .attr('transform', (d) => 'translate(' + source.y + ',' + source.x + ')')
      .remove();

    nodeExit.select('circle')
      .attr('r', '0%');

    nodeExit.select('text')
      .style('fill-opacity', 1e-6);

    const link = this.svg.selectAll('path.link')
      .data(links, (d) => d.id);

    const linkEnter = link.enter().insert('path', 'g')
      .attr('class', 'link')
      .attr('d', (d) => {
        const o = { x: source.x0, y: source.y0 };
        return diagonal(o, o);
      });

    const linkUpdate = linkEnter.merge(link);

    linkUpdate.transition()
      .duration(this.duration)
      .attr('d', (d) => diagonal(d, d.parent));

    link.exit().transition()
      .duration(this.duration)
      .attr('d', (d) => {
        const o = { x: source.x, y: source.y };
        return diagonal(o, o);
      }).remove();

    nodes.forEach((d) => {
      d.x0 = d.x;
      d.y0 = d.y;
    });

    function diagonal(s, d) {
      const path = `M ${s.y} ${s.x}
            C ${(s.y + d.y) / 2} ${s.x},
              ${(s.y + d.y) / 2} ${d.x},
              ${d.y} ${d.x}`;

      return path;
    }
  }

  click(d: any) {
    if (d.children) {
      d._children = d.children;
      d.children = null;
    } else {
      d.children = d._children;
      d._children = null;
    }
    this.updateTree(d);
  }
}
