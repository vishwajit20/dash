import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../service/login.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  loginStatus;
  constructor(private route: Router, private loginService: LoginService) {
    this.loginStatus = !sessionStorage.getItem('auth');
    this.loginService.loginStatus$.subscribe((value: boolean) => {
      this.loginStatus = value;
    })
  }

  ngOnInit() {
  }

  logout() {
    sessionStorage.removeItem('auth');
    this.loginStatus = false;
    this.route.navigate(['dashboard']);
    this.loginService.loginStatus.next(true);
  }
}
