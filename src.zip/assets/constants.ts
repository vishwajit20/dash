
export const DEP_SERVERS = {
    RIH: [{
        name: 'BO', details: {
            'Out Feed': [
                'CONS Creation',
                'Scan Posting',
                'SEP Posting',
                'Print On Demand',
                'Departure',
                'Manifest for destination'
            ],
        }
    }, {
        name: 'SLASH', details: {
            'Pre Sort': ['Manifest Download',
                'Clearance status',
                'Address Correction'
            ]
        }
    }],
    RAPTOR: ['no depedency'],
    GENIUS : [{ name: 'SABRE', details: {
    'Out Feed': [ 'CONS Creation',
        'Scan Posting',
        'SEP Posting',
        'Print On Demand',

        'Departure',
        'Manifest for destination'
    ]}}],
    HORUS: ['no depedency'],
    GSS: [{ name: 'ITIH' }, { name: 'SLASH' }, { name: 'FRD' }, { name: 'AS400' }],
    PHASAR: ['no depedency'],
    EISTC: [{ name: 'ITIH' , details: {'In Feed': [{
        name: 'Scan Package',
        info: 'The package delivery company will also X-ray entire truckloads of parcels at its sorting facility'
    },
        'Scan Posting',
        'Dim / Weight',
        'Label Printing',
        'Sorting',
        'Chute Selection',
        'Logical Split'
    ]}},  
    {
        name: 'SABRE', details: {
            'In Feed': [{
                name: 'Scan Package',
                info: 'The package delivery company will also X-ray entire truckloads of parcels at its sorting facility'
            },
                'Scan Posting',
                'Dim / Weight',
                'Label Printing',
                'Sorting',
                'Chute Selection',
                'Logical Split'
            ],
            'Cage': ['Cage In',
                'Cage Out',
                'Cage Report',
                'Print On Demand',
                'Re-Manifest',
                'Address Correction',
                'Instruction Assignment'
            ],
            'Out Feed': [
                'CONS Creation',
                'Scan Posting',
                'SEP Posting',
                'Print On Demand',
                'Departure',
                'Manifest for destination'
            ]
        }
    }, { name: 'Scan Device' }],
    APOLLO: ['no depedency'],
    SABRE: [{
        name: 'GSS', details: {
            'In Feed': [{
                name: 'Scan Package',
                info: 'Scan Package info'
            },
            {
                name: 'Scan Posting',
                info: 'Consolidates parcels from merchants such as e-commerce and catalog companies and uses the United States Postal Service for the final delivery. Formerly the independent company Parcel Direct until FedEx acquired it for $120 million in 2004'
            },
                'Dim / Weight',
                'Label Printing',
                'Sorting',
                'Chute Selection',
                'Logical Split'
            ],
            'Out Feed': [
                'CONS Creation',
                'Scan Posting',
                'SEP Posting',
                'Print On Demand',
                'Departure',
                'Manifest for destination'
            ]
        }
    }, {
        name: 'RIH', details: {
            'Pre Sort': ['Manifest Download',
                'Clearance status',
                'Address Correction',
                'Manifest Correction'
            ]
        }
    }
    ],
    AS400: ['no depedency'],
    VISA: [{ name: 'SEP' }, 
        { name: 'SABRE', details :{
            'Pre Sort' :['Manifest Download',
            'Clearance status',
            'Address Correction',
            'Manifest Correction'
        ], 
            'In Feed':[ 'Scan Package',               
                'Dim / Weight',
                'Label Printing',
                'Sorting',
                'Chute Selection',
                'Logical Split'], 
            'Cage':['Cage In',
            'Cage Out',
            'Cage Report',
            'Print On Demand',
            'Re-Manifest',
            'Address Correction',
            'Instruction Assignment'], 
            'Out Feed':['CONS Creation',
            'Scan Posting',
            'SEP Posting',
            'Print On Demand',
            'Departure',
            'Manifest for destination']
        }}, 
    
        { name: 'GSS' , details: {
        'In Feed': [{
            name: 'Scan Package',
            info: 'Scan Package info'
        },
        {
            name: 'Scan Posting',
            info: 'Consolidates parcels from merchants such as e-commerce and catalog companies and uses the United States Postal Service for the final delivery. Formerly the independent company Parcel Direct until FedEx acquired it for $120 million in 2004'
        },
            'Dim / Weight',
            'Label Printing',
            'Sorting',
            'Chute Selection',
            'Logical Split'
        ],
        'Out Feed': [
            'CONS Creation',
            'Scan Posting',
            'SEP Posting',
            'Print On Demand',
            'Departure',
            'Manifest for destination'
        ]
    }}]
};

export const LOCATIONS =
{
    DETAILS_CDG: [
        {
            appName: 'RIH',
            status: 'running',
            depedentServers: ['BO', 'SLASH'],
            info: 'RIH'
        },
        {
            appName: 'EISTC',
            status: 'running',
            depedentServers: ['ITIH',  'SABRE'],
            info: 'SETS No. 341644'
        }
    ],
    DETAILS_CGN: [
        {
            appName: 'RAPTOR',
            status: 'running',
            depedentServers: ['no depedency'],
            info: 'RAPTOR'
        },
        {
            appName: 'HORUS',
            status: 'running',
            depedentServers: ['no depedency'],
            info: 'HORUS'
        },
        {
            appName: 'GSS',
            status: 'running',
            depedentServers: [
                'ITIH',
                'SLASH',
                'FRD',
                'AS400',
                'Sort Monitoring',
                'Scan Device'
            ],
            info: 'GSS'
        },
        {
            appName: 'APOLLO',
            status: 'running',
            depedentServers: ['SABRE'],
            info: 'APOLLO'
        }],

    DETAILS_DXB: [
        {
            appName: 'SABRE',
            status: 'running',
            depedentServers: [
                'GSS',
                'RIH'
            ],
            info: 'SABRE'
        },
        {
            appName: 'AS400',
            status: 'running',
            depedentServers: [
                'SABRE',
                'Genius'
            ],
            info: 'AS400'
        },
        {
            appName: 'VISA',
            status: 'running',
            depedentServers: [
                'SABRE',
                'AS400'
            ],
            info: 'VISA'
        },
        {
            appName: 'GENIUS',
            status: 'running',
            depedentServers: [
                'SABRE'
            ],
            info: 'GENIUS'
        }],
    DETAILS_MXP: [
        {
            appName: 'SABRE',
            status: 'running',
            depedentServers: [
                'GSS',
                'RIH'
            ],
            info: 'SABRE'
        },
        {
            appName: 'AS400',
            status: 'running',
            depedentServers: [
                'SABRE',
                'GENIUS'
            ],
            info: 'AS400'
        },
        {
            appName: 'VISA',
            status: 'running',
            depedentServers: [
                'SEP',
                'SABRE',
                'GSS'
            ],
            info: 'VISA'
        },
        {
            appName: 'GENIUS',
            status: 'running',
            depedentServers: [
                'SABRE'
            ],
            info: 'SETS No. 341599'
        }],
    DETAILS_CPH: [
        {
            appName: 'SABRE',
            status: 'running',
            depedentServers: [
                'GSS',
                'RIH'
            ],
            info: 'SABRE'
        },
        {
            appName: 'AS400',
            status: 'running',
            depedentServers: [
                'SABRE',
                'GENIUS'
            ],
            info: 'AS400'
        },
        {
            appName: 'VISA',
            status: 'running',
            depedentServers: [
                'SABRE',
                'AS400'
            ],
            info: 'VISA'
        },
        {
            appName: 'GENIUS',
            status: 'running',
            depedentServers: ['SABRE'],
            info: 'GENIUS'
        }]
}
export const MESSAGE = 'ADD MESSAGE HERE';
