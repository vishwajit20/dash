export const environment = {
  production: true,
  //baseUIUrl: 'http://localhost:4200/',
  baseAPIUrl: 'http://dawn.emea.fedex.com:7002/'
};
